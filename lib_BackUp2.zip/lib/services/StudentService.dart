import 'dart:convert';
import 'package:http/http.dart' as http;

class Studentservice {
  static const String baseUrl = "http://192.168.0.104:3000";
  // static const String baseUrl = "http://192.168.61.95:3000";
  // Function get District
  static Future<List<dynamic>> getStudents() async {
    final response = await http.get(Uri.parse("$baseUrl/std/select"));
    print("API response: ${response.body}");
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception("Failed to load unit: ${response.statusCode}");
    }
  }

  static Future<List<dynamic>> searchStudents(String stdName) async {
    final response = await http.get(
      Uri.parse("$baseUrl/std/search/payment?stdName=$stdName"),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception("Failed to search District: ${response.statusCode}");
    }
  }

  // Function Add District
  static Future<bool> addDistrict(String dname, int pid) async {
    final response = await http.post(
      Uri.parse("$baseUrl/district/create"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"dname": dname, "pid": pid}),
    );
    return response.statusCode == 201;
  }

  // Function Delete District
  static Future<bool> deleteDistrict(int dsid) async {
    final response = await http.delete(
      Uri.parse("$baseUrl/district/delete/$dsid"),
    );
    return response.statusCode == 200;
  }

  // Function Update District
  static Future<bool> updateDistrict(int dsid, String dname, int? value) async {
    final response = await http.put(
      Uri.parse("$baseUrl/district/update/$dsid"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"dname": dname, "pid": value}),
    );
    return response.statusCode == 200;
  }

  static Future<bool> updatePaymentStatus(String stdID, int payStID) async {
    final response = await http.put(
      Uri.parse("$baseUrl/std/updatePayment/$stdID"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "paySt_id": payStID, // ✅ ต้องตรงกับ backend
      }),
    );

    return response.statusCode == 200;
  }
}
