import 'package:flutter/material.dart';
import 'package:registration_evaluation_app/MyApp.dart';

void main() {
  runApp(const MyApp());
}
