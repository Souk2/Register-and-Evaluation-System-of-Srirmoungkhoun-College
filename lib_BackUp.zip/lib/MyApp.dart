import 'package:flutter/material.dart';
import 'package:registration_evaluation_app/screens/DistrictScreen.dart';
import 'package:registration_evaluation_app/screens/LoginScreen%20.dart';
import 'package:registration_evaluation_app/screens/ProvinceScreen.dart';
import 'package:registration_evaluation_app/screens/academic/academicScreen.dart';
import 'package:registration_evaluation_app/screens/student/StudentScreen.dart';
import 'package:registration_evaluation_app/screens/add/AddDistrictScreen.dart';
import 'package:registration_evaluation_app/screens/registation/newStudent.dart';
import 'package:registration_evaluation_app/screens/registation/REStudent.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: NewStudent(),
    );
  }
}
